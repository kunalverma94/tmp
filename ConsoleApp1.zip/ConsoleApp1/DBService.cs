﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
public class TextEmbedding: IDoc
{
    [BsonId]
    public int ID { get; set; }
    public string Text { get; set; }
    public float[] Embedding { get; set; }
}
public class DatabaseSettings
{
    public string ConnectionString { get; set; } = "mongodb://localhost:27017";

    public string DatabaseName { get; set; } = "zzz";

    public string CollectionName { get; set; } = "embedings";
}
public class DBService<T> where T:IDoc
{
    public readonly IMongoCollection<T> _collection;

    public DBService(DatabaseSettings bookStoreDatabaseSettings)
    {
        var mongoClient = new MongoClient(
            bookStoreDatabaseSettings.ConnectionString);

        var mongoDatabase = mongoClient.GetDatabase(
            bookStoreDatabaseSettings.DatabaseName);

        _collection = mongoDatabase.GetCollection<T>(
            bookStoreDatabaseSettings.CollectionName);
    }
    public DBService()
    {
        var bookStoreDatabaseSettings = new DatabaseSettings();
        var mongoClient = new MongoClient(
            bookStoreDatabaseSettings.ConnectionString);

        var mongoDatabase = mongoClient.GetDatabase(
            bookStoreDatabaseSettings.DatabaseName);

        _collection = mongoDatabase.GetCollection<T>(
            bookStoreDatabaseSettings.CollectionName);
    }

    public async Task<List<T>> GetAsync() =>
        await _collection.Find(_ => true).ToListAsync();

    public async Task<T?> GetAsync(int id) =>
        await _collection.Find(x => x.ID == id).FirstOrDefaultAsync();

    public async Task CreateAsync(T newlanguage) =>
        await _collection.InsertOneAsync(newlanguage);

    public async Task UpdateAsync(int id, T language) =>
        await _collection.ReplaceOneAsync(x => x.ID == id, language);

    public async Task RemoveAsync(int id) =>
        await _collection.DeleteOneAsync(x => x.ID == id);

    public async Task<int> GetCount()
    {
        int count = Convert.ToInt32(await _collection.CountDocumentsAsync(_ => true));
        return count;
    }
}
