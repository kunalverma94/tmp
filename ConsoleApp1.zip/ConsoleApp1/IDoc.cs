﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
public interface IDoc
{
    [BsonId]
    public int ID { get; set; }
}




namespace Darwin.ChatBot.API.Services
{
    //public class Runner
    //{
    //    public static void Main()
    //    {
    //        int i = 0;
    //        Thread t = new Thread(() =>
    //        {
    //            while (true)
    //            {
    //                Console.WriteLine("..." + i);
    //                Thread.Sleep(5000);
    //                i++;
    //            }
    //        });
    //        t.Start();
    //        var f = NewMethod();

    //        NewMethod1(f, t);
    //    }

    //    private static async Task NewMethod1(IAsyncEnumerable<Tuple<string, bool>> f, Thread t)
    //    {
    //        await foreach (var item in f)
    //        {
    //            await Console.Out.WriteLineAsync(item.Item1);
    //            await Console.Out.WriteLineAsync(item.Item2.ToString());
    //        }
    //    }

    //    private static async IAsyncEnumerable<Tuple<string, bool>> NewMethod()
    //    {
    //        string text = File.ReadAllText(@"D:\Users\kunal.verma2\Desktop\911\aranyakanda_english.txt");
    //        var ff = text.Split(".");//Select((a,i)=>new  { Index=i, Value=a}).GroupBy(z=>z.Index/250).Select(a=> string.Join("", a.Select(b => b.Value))).ToList();
    //        var f = new LenAIService();
    //        for (int i = 0; i <= ff.Length; i++)
    //        {
    //            var item = ff[i];
    //            while (item.Length <= 250)
    //            {
    //                item += ff[++i] + ". ";
    //            }

    //            bool isSuccess = await f.StoreEmbeddingAsync(item);
    //            while (!isSuccess)
    //            {
    //                isSuccess = await f.StoreEmbeddingAsync(item);
    //            }
    //            yield return new Tuple<string, bool>(item, isSuccess);

    //        }
    //    }
    //}
    public class LenAIService
    {
        private readonly string _endpoint;
        private readonly string _deploymentId;
        private readonly string _deploymentIdVector;
        private readonly string _embeddingModelName;
        private readonly string _completionModelName;
        public readonly HttpClient _client;
        private readonly string apiKey = "bca6c166-cc40-4633-992b-fcfb243a89ed-d096d7ad-9490-4766-b3a3-a4dced93d9b0";
        DBService<TextEmbedding> dBService = new DBService<TextEmbedding>();

        public LenAIService()
        {
            _endpoint = "https://stg1.mmc-dallas-int-non-prod-ingress.mgti.mmc.com/coreapi/openai/v1/deployments";
            _deploymentId = "mmc-tech-gpt-35-turbo";
            _deploymentIdVector = "mmc-tech-text-embedding-ada-002";
            _embeddingModelName = "text-embedding-ada-002";
            _completionModelName = "gpt-35-turbo";

            _client = new HttpClient
            {
                DefaultRequestHeaders =
                {
                    {"Authorization", $"Bearer {apiKey}"},
                }
            };
        }


        public async Task<bool> StoreEmbeddingAsync(string text)
        {
            try
            {
                var embedding = await GetEmbeddingsAsync(text);
                if (embedding == null)
                {
                    return false;
                }
                var embeddingDocument = new TextEmbedding
                {
                    ID = (await dBService.GetCount()) + 1,
                    Text = text,
                    Embedding = embedding
                };
                await dBService.CreateAsync(embeddingDocument);
                Console.WriteLine("Embedding stored successfully!");
            }
            catch (Exception e)
            {
                await Console.Out.WriteLineAsync(e.Message);

                return false;
            }
            return true;
        }


        public async Task<float[]> GetEmbeddingsAsync(string data)
        {
            string json = JsonSerializer.Serialize(new
            {
                model = _embeddingModelName,
                input = data,
            });

            using StringContent postData = new(json, Encoding.UTF8, "application/json");

            using HttpResponseMessage response = await _client.PostAsync($"{_endpoint}/{_deploymentIdVector}/embeddings", postData);

            if (!response.IsSuccessStatusCode)
            {
                new HttpRequestException($"API request failed with status code: {response.StatusCode}");
                return null;
            }

            string responseContent = await response.Content.ReadAsStringAsync();

            try
            {
                JsonDocument jsonResponse = JsonDocument.Parse(responseContent);
                JsonElement embeddingElement = jsonResponse.RootElement.GetProperty("data")[0].GetProperty("embedding");

                if (embeddingElement.ValueKind != JsonValueKind.Array)
                {
                    throw new InvalidOperationException("The 'embedding' property is not an array.");
                }

                List<float> embeddings = [];
                foreach (JsonElement element in embeddingElement.EnumerateArray())
                {
                    if (element.TryGetSingle(out float value))
                    {
                        embeddings.Add(value);
                    }
                    else
                    {
                        throw new InvalidOperationException("Failed to parse a float value from the 'embedding' array.");
                    }
                }

                return [.. embeddings];
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse the JSON response.", ex);
            }
        }

        public async Task<string> GetResponseAsync(string question, string customPrompt)
        {
            string json = JsonSerializer.Serialize(new
            {
                model = _completionModelName,
                messages = new[] {
                    new {
                        role = "user",
                        content = $"{customPrompt} {question}"
                    }
                },
            });

            using StringContent postData = new(json, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _client.PostAsync($"{_endpoint}/{_deploymentId}/chat/completions", postData);

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"API request failed with status code: {response.StatusCode}");
            }

            string responseContent = await response.Content.ReadAsStringAsync();

            try
            {
                JsonDocument jsonResponse = JsonDocument.Parse(responseContent);
                return jsonResponse.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString() ?? string.Empty;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse the JSON response.", ex);
            }
        }
    }
}
