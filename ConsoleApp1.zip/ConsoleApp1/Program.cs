﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Darwin.ChatBot.API.Services;
using MongoDB.Driver;
using static System.Net.Mime.MediaTypeNames;

public class VectorSearch
{

    public VectorSearch()
    {
      
    }

    public async Task QueryVectorStoreAsync(string query)
    {
        // Step 1: Get embedding for the query text
        var queryEmbedding = await new LenAIService().GetEmbeddingsAsync(query);
        if (queryEmbedding ==null)
        {
            await Console.Out.WriteLineAsync(   "error");
            return;
        }
        // Step 2: Fetch and calculate similarity with stored embeddings
        DBService<TextEmbedding> dBService = new DBService<TextEmbedding>();
        var results = await dBService._collection.Find(_ => true).ToListAsync();

        var scoredResults = results.Select(doc => new
        {
            Text = doc.Text,
            Score = CosineSimilarity(queryEmbedding, doc.Embedding)
        })
        .OrderByDescending(result => result.Score)
        .Take(5) // Retrieve top 5 matches (adjust as needed)
        .ToList();

        // Display results
        foreach (var result in scoredResults)
        {
            Console.WriteLine($"Text: {result.Text}\nScore: {result.Score}\n");
        }
    }

    //private async Task<float[]> GetEmbeddingAsync(string text)
    //{

    //    var result = await _api.Embeddings.CreateEmbeddingAsync(text);
    //    return result.Data[0].Embedding.ToArray();
    //}

    private float CosineSimilarity(float[] vecA, float[] vecB)
    {
        float dotProduct = 0f, magnitudeA = 0f, magnitudeB = 0f;
        for (int i = 0; i < vecA.Length; i++)
        {
            dotProduct += vecA[i] * vecB[i];
            magnitudeA += vecA[i] * vecA[i];
            magnitudeB += vecB[i] * vecB[i];
        }
        return dotProduct / (float)(Math.Sqrt(magnitudeA) * Math.Sqrt(magnitudeB));
    }
}

public class www
{

    public static async Task Main(string[] args)
    {
        var g = new DBService<TextEmbedding>();
        //var vectorSearch = new VectorSearch();
        //await vectorSearch.QueryVectorStoreAsync("who is Sugriva ?");
    }
}
